package com.example.ukshinhoti_fshk.department;

import com.example.ukshinhoti_fshk.subject.Subject;

import java.util.List;


public class Department{
    private long id;
    private String name;
    private String description;
    private List<Staff> staffList;
    private List<Subject> subjectList;

    public Department(String name, String description, List<Staff> staffList , List<Subject> subjectList) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.staffList = staffList;
        this.subjectList = subjectList;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public List<Staff> getStaffList() {
        return staffList;
    }

    public void setStaffList(List<Staff> staffList) {
        this.staffList = staffList;
    }

    public List<Subject> getSubjectList() {
        return subjectList;
    }

    public void setSubjectList(List<Subject> subjectList) {
        this.subjectList = subjectList;
    }
}