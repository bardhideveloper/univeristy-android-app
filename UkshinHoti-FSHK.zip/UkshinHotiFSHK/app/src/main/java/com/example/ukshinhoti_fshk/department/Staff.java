package com.example.ukshinhoti_fshk.department;

public class Staff {
    private long id;
    private String officeNumber;
    private String floor;
    private String professorEmail;
    private String consultationHours;
    private Department department;


    public Staff(long id, String officeNumber, String floor, String professorEmail, String consultationHours, Department department) {
        this.id = id;
        this.officeNumber = officeNumber;
        this.floor = floor;
        this.professorEmail = professorEmail;
        this.consultationHours = consultationHours;
        this.department = department;
    }

    public long getId() {
        return id;
    }

    public String getOfficeNumber() {
        return officeNumber;
    }

    public String getFloor() {
        return floor;
    }

    public String getProfessorEmail() {
        return professorEmail;
    }

    public String getConsultationHours() {
        return consultationHours;
    }

    public Department getDepartment() {
        return department;
    }

    public void setId(long id) {
        this.id = id;
    }

    public void setOfficeNumber(String officeNumber) {
        this.officeNumber = officeNumber;
    }

    public void setFloor(String floor) {
        this.floor = floor;
    }

    public void setProfessorEmail(String professorEmail) {
        this.professorEmail = professorEmail;
    }

    public void setConsultationHours(String consultationHours) {
        this.consultationHours = consultationHours;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }
}