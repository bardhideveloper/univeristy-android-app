package com.example.ukshinhoti_fshk;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ListView;

import com.example.ukshinhoti_fshk.contact.Contact;
import com.example.ukshinhoti_fshk.contact.ContactAdapter;

import java.util.ArrayList;
import java.util.List;

public class ContactActivity extends AppCompatActivity {
    private ListView listOfContacts;
    private ContactAdapter adapter;
    private List<Contact> contactList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact);

        // Enable the "Go Back" button in the app bar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        listOfContacts = findViewById(R.id.listOfContact);

        // Create a list of contacts
        contactList = new ArrayList<>();
        contactList.add(new Contact("Universiteti i Prizrenit", "1234567890", "support.it@uni-prizren.com"));
        contactList.add(new Contact("UPZ - Rr.Rruga e Shkronjave 1 Prizren , Kosove ", "0987654321", "support.it@uni-prizren.com"));
        contactList.add(new Contact("Webfaqe","https://www.uni-prizren.com/",""));

        // Create and set the adapter
        adapter = new ContactAdapter(this, contactList);
        listOfContacts.setAdapter(adapter);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed(); // Go back to the previous activity
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}