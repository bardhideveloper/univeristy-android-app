package com.example.ukshinhoti_fshk;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;
import android.widget.ListView;

import com.example.ukshinhoti_fshk.event.Event;
import com.example.ukshinhoti_fshk.event.EventAdapter;

import java.util.ArrayList;
import java.util.List;

public class EventsActivity extends AppCompatActivity {
    private ListView listOfEvents;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events);

        // Enable the "Go Back" button in the app bar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        listOfEvents = findViewById(R.id.listOfEvents);

        // Create a list of events
        List<Event> events = createEventList();

        // Create an adapter to display the events in the ListView
        EventAdapter eventAdapter = new EventAdapter(this, events);

        // Set the adapter for the ListView
        listOfEvents.setAdapter(eventAdapter);
    }

    private List<Event> createEventList() {
        // Create a list of events
        List<Event> events = new ArrayList<>();

        // Add events to the list
        Event event1 = new Event("Event 1", "2023-05-22", "Description 1");
        events.add(event1);

        Event event2 = new Event("Event 2", "2023-05-23", "Description 2");
        events.add(event2);

        Event event3 = new Event("Event 3", "2023-05-23", "Description 3");
        events.add(event3);

        Event event4 = new Event("Event 4", "2023-05-23", "Description 4");
        events.add(event4);

        Event event5 = new Event("Event 5", "2023-05-23", "Description 5");
        events.add(event5);

        Event event6 = new Event("Event 6", "2023-05-23", "Description 6");
        events.add(event6);

        Event event7 = new Event("Event 7", "2023-05-23", "Description 7");
        events.add(event7);

        return events;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed(); // Go back to the previous activity
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}