package com.example.ukshinhoti_fshk;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.example.ukshinhoti_fshk.department.Staff;
import com.example.ukshinhoti_fshk.subject.Subject;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class SubjectDepartmentActivity extends AppCompatActivity {

    private ListView listOfSubjects;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subject_department);

        // Enable the "Go Back" button in the app bar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        listOfSubjects = findViewById(R.id.listOfSubjects);

        Button addSubjectButton = findViewById(R.id.addSubjectButton);
        addSubjectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAddSubjectDialog();
            }
        });

        // Retrieve the department ID from the intent
        int departmentId = getIntent().getIntExtra("departmentId",+1);
        System.out.println("id: "+departmentId);

        // Construct the URL to fetch staff data for the given department ID
        String url = "http://192.168.0.11:8080/departments/" + departmentId + "/subjects";

        // Execute the API request to fetch staff data
        new SubjectDepartmentActivity.ReadSubjectAPI().execute(url);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed(); // Go back to the previous activity
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    //Listener to add a new Staff
    private void showAddSubjectDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add Subject");

        // Inflate the dialog layout XML file
        View view = getLayoutInflater().inflate(R.layout.dialog_add_subjectdepartment, null);
        builder.setView(view);

        // Get references to the EditText fields
        EditText NameEditText = view.findViewById(R.id.editTextName);
        EditText CreditsEditText = view.findViewById(R.id.editTextCredits);


        // Retrieve the department ID from the intent
        int departmentId = getIntent().getIntExtra("departmentId", -1);

        builder.setPositiveButton("Add", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String Name = NameEditText.getText().toString().trim();
                String Credits = CreditsEditText.getText().toString().trim();

                // Create a new JSONObject to hold the staff data
                JSONObject subject = new JSONObject();
                try {
                    subject.put("name", Name);
                    subject.put("credits", Credits);
                    subject.put("departmentId",departmentId);

                } catch (JSONException e) {
                    e.printStackTrace();
                }

                // Send a POST request to add the new staff member
                String addUrl = "http://192.168.0.11:8080/subjects/add"; // Replace with your server URL
                String requestBody = subject.toString(); // Convert the JSON object to a string
                new SubjectDepartmentActivity.AddSubjectTask().execute(addUrl, requestBody);
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private class ReadSubjectAPI extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {
            String url = strings[0];
            APIHandler handler = new APIHandler();
            return handler.readJson(url);
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            try {
                JSONArray jsonArray = new JSONArray(result);
                List<Subject> subjectList = new ArrayList<>();

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    long id = jsonObject.getLong("id");
                    String name = jsonObject.getString("name");
                    String credits = jsonObject.getString("credits");

                    // Create a new Staff object
                    Subject subject = new Subject(id, name,credits,null);
                    subjectList.add(subject);
                }

                ArrayAdapter<Subject> adapter = new ArrayAdapter<Subject>(SubjectDepartmentActivity.this, R.layout.list_item_subjectdepartmet, R.id.textViewName, subjectList) {
                    @NonNull
                    @Override
                    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                        if (convertView == null) {
                            convertView = getLayoutInflater().inflate(R.layout.list_item_subjectdepartmet, parent, false);
                        }

                        Subject subject = getItem(position);

                        TextView textViewName = convertView.findViewById(R.id.textViewName);
                        TextView textViewCredits = convertView.findViewById(R.id.textViewCredits);


                        textViewName.setText("Name: " + subject.getName());
                        textViewCredits.setText("Credits: " + subject.getCredits());


                        convertView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                showEditDeleteDialog(subject);
                            }
                        });

                        return convertView;
                    }
                };

                listOfSubjects.setAdapter(adapter);

                listOfSubjects.setAdapter(adapter);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class AddSubjectTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String url = params[0];
            String requestBody = params[1];
            APIHandler handler = new APIHandler();

            try {
                JSONObject subjectObject = new JSONObject(requestBody);

                return handler.sendPostRequest(url, subjectObject.toString());
            } catch (JSONException e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            // Construct the URL to fetch staff data for the given department ID
            int departmentId = getIntent().getIntExtra("departmentId",+1);
            String url = "http://192.168.0.11:8080/departments/" + departmentId + "/subjects";

            // Execute the API request to fetch staff data
            new SubjectDepartmentActivity.ReadSubjectAPI().execute(url);
        }
    }

    private void showEditSubjectDialog(Subject subject) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Subject");

        // Inflate the dialog layout XML file
        View view = getLayoutInflater().inflate(R.layout.dialog_add_subjectdepartment, null);
        builder.setView(view);

        // Get references to the EditText fields
        EditText nameEditText = view.findViewById(R.id.editTextName);
        EditText creditsEditText = view.findViewById(R.id.editTextCredits);


        // Pre-fill the EditText fields with the existing values
        nameEditText.setText(subject.getName());
        creditsEditText.setText(subject.getCredits());

        builder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String name = nameEditText.getText().toString().trim();
                String credits = creditsEditText.getText().toString().trim();

                // Update the staff member with the new values
                subject.setName(name);
                subject.setCredits(credits);


                // Send a PUT request to update the staff member
                String updateUrl = "http://192.168.0.11:8080/subjects/" + subject.getId(); // Replace with your server URL
                String requestBody = subjectToJson(subject); // Convert the Staff object to a JSON string
                new SubjectDepartmentActivity.UpdateSubjectTask().execute(updateUrl, requestBody);
            }
        });

        builder.setNegativeButton("Cancel", null);

        builder.show();
    }

    private void showDeleteSubjectDialog(Subject subject) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete Subject");
        builder.setMessage("Are you sure you want to delete this subject");

        builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Send a DELETE request to remove the staff member
                String deleteUrl = "http://192.168.0.11:8080/subjects/" + subject.getId(); // Replace with your server URL
                new SubjectDepartmentActivity.DeleteSubjectTask().execute(deleteUrl);
            }
        });

        builder.setNegativeButton("Cancel", null);

        builder.show();
    }


    private void showEditDeleteDialog(Subject subject) {
        AlertDialog.Builder builder = new AlertDialog.Builder(SubjectDepartmentActivity.this);
        builder.setTitle("Options");
        builder.setItems(new CharSequence[]{"Edit", "Delete"}, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (which == 0) {
                    // Edit option clicked
                    showEditSubjectDialog(subject);
                } else if (which == 1) {
                    // Delete option clicked
                    showDeleteSubjectDialog(subject);
                }
            }
        });
        builder.show();
    }
    private String subjectToJson(Subject subject) {
        // Create a new JSONObject to hold the staff data
        JSONObject subjectObject = new JSONObject();
        try {
            subjectObject.put("id", subject.getId());
            subjectObject.put("name", subject.getName());
            subjectObject.put("credits", subject.getCredits());

        } catch (JSONException e) {
            e.printStackTrace();
        }

        return subjectObject.toString();
    }

    private class UpdateSubjectTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String url = params[0];
            String requestBody = params[1];
            APIHandler handler = new APIHandler();

            return handler.sendPutRequest(url, requestBody);
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            // Refresh the staff list after updating the staff member
            String url = "http://192.168.0.11:8080/subjects"; // Replace with your server URL
            new SubjectDepartmentActivity.ReadSubjectAPI().execute(url);
        }
    }

    private class DeleteSubjectTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String url = params[0];
            APIHandler handler = new APIHandler();

            return handler.sendDeleteRequest(url);
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            // Refresh the staff list after deleting the staff member
            String url = "http://192.168.0.11:8080/subjects"; // Replace with your server URL
            new SubjectDepartmentActivity.ReadSubjectAPI().execute(url);
        }
    }

}