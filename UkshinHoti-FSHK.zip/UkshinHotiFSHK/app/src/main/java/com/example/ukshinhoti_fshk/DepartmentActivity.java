package com.example.ukshinhoti_fshk;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.ukshinhoti_fshk.department.Staff;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class DepartmentActivity extends AppCompatActivity {
        private ListView listOfDepartments;
        public int departmentId=-1;

        @SuppressLint("MissingInflatedId")
        @Override
        protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_department);

        // Enable the "Go Back" button in the app bar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        listOfDepartments = findViewById(R.id.listOfDepartments);

        //Listener to add a new department
        Button addDepartmentButton = findViewById(R.id.addDepartmentButton);
        addDepartmentButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAddDepartmentDialog();
            }
        });
        new ReadAPI().execute("http://192.168.0.11:8080/departments");
        }

        @Override
        public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed(); // Go back to the previous activity
            return true;
        }
        return super.onOptionsItemSelected(item);
        }

        //Dialog to add a new department
        private void showAddDepartmentDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add Department");

        // Inflate the dialog layout XML file
        View view = getLayoutInflater().inflate(R.layout.dialog_add_department, null);
        builder.setView(view);

        // Get references to the EditText fields
        EditText nameEditText = view.findViewById(R.id.editTextName);
        EditText descriptionEditText = view.findViewById(R.id.editTextDescription);

        builder.setPositiveButton("Add", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String name = nameEditText.getText().toString().trim();
                String description = descriptionEditText.getText().toString().trim();

                // Create a new JSONObject to hold the department data
                JSONObject department = new JSONObject();
                try {
                    department.put("name", name);
                    department.put("description", description);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                // Send a POST request to add the new department
                String addUrl = "http://192.168.0.11:8080/departments"; // Replace with your server URL
                String requestBody = department.toString(); // Convert the JSON object to a string
                new AddDepartmentTask().execute(addUrl, requestBody);
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog alertDialog = builder.create();
        alertDialog.show();
        }

        private class ReadAPI extends AsyncTask<String, Void, String> {

            @Override
            protected String doInBackground(String... strings) {
                String url = strings[0];
                APIHandler handler = new APIHandler();
                return handler.readJson(url);
            }

            @Override
            protected void onPostExecute(String result) {
                super.onPostExecute(result);

                try {
                    JSONArray jsonArray = new JSONArray(result);
                    List<JSONObject> allDepartments = new ArrayList<>();

                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject jsonObject = jsonArray.getJSONObject(i);
                        allDepartments.add(jsonObject);
                    }

                    ArrayAdapter<JSONObject> adapter = new ArrayAdapter<JSONObject>(DepartmentActivity.this,
                            R.layout.list_item_department, allDepartments) {
                        @NonNull
                        @Override
                        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                            if (convertView == null) {
                                convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item_department, parent, false);
                            }

                            JSONObject department = getItem(position);

                            TextView nameTextView = convertView.findViewById(R.id.textViewDepartmentName);
                            TextView descriptionTextView = convertView.findViewById(R.id.textViewDepartmentDescription);
                            Button viewStaffButton = convertView.findViewById(R.id.buttonViewStaff);
                            Button viewSubjectsButton = convertView.findViewById(R.id.buttonViewSubjects);

                            try {
                                // Set the department name and description
                                String departmentName = department.getString("name");
                                String departmentDescription = department.getString("description");
                                nameTextView.setText(departmentName);
                                descriptionTextView.setText(departmentDescription);

                                // Set click listener for the "Edit" button
                                Button editButton = convertView.findViewById(R.id.buttonEdit);
                                editButton.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        try {
                                            int departmentId = department.getInt("id");
                                            String departmentName = department.getString("name");
                                            String departmentDescription = department.getString("description");
                                            editDepartment(departmentId, departmentName, departmentDescription);
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                });

                                // Set click listener for the "Delete" button
                                Button deleteButton = convertView.findViewById(R.id.buttonDelete);
                                deleteButton.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        try {
                                            int departmentId = department.getInt("id");
                                            new DeleteDepartmentTask().execute(departmentId);
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                });

                                // Set click listener for the "Staf" button
                                viewStaffButton.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        try {
                                            int departmentId = department.getInt("id");
                                            System.out.println("departamenti id: "+departmentId+";;");
                                            // Create an intent to launch the new activity
                                            Intent intent = new Intent(DepartmentActivity.this, StaffActivity.class);
                                            // Pass the department ID to the new activity
                                            intent.putExtra("departmentId", departmentId);
                                            // Start the new activity
                                            startActivity(intent);
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                });

                                viewSubjectsButton.setOnClickListener(new View.OnClickListener() {
                                    @Override
                                    public void onClick(View v) {
                                        try {
                                            int departmentId = department.getInt("id");
                                            System.out.println("departamenti id: "+departmentId+";;");
                                            // Create an intent to launch the new activity
                                            Intent intent1 = new Intent(DepartmentActivity.this, SubjectDepartmentActivity.class);
                                            // Pass the department ID to the new activity
                                            intent1.putExtra("departmentId", departmentId);
                                            // Start the new activity
                                            startActivity(intent1);
                                        } catch (JSONException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                });

                            } catch (JSONException e) {
                                e.printStackTrace();
                            }
                            return convertView;
                        }
                    };

                    listOfDepartments.setAdapter(adapter);

                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }

    // Edit Department method ()
    private void editDepartment(int id, String name, String description) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Department");

        // Inflate the dialog layout XML file
        View view = getLayoutInflater().inflate(R.layout.dialog_edit_department, null);
        builder.setView(view);

        // Get references to the EditText fields
        EditText nameEditText = view.findViewById(R.id.editTextName);
        EditText descriptionEditText = view.findViewById(R.id.editTextDescription);
        nameEditText.setText(name);
        descriptionEditText.setText(description);

        builder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String updatedName = nameEditText.getText().toString().trim();
                String updatedDescription = descriptionEditText.getText().toString().trim();

                // Create a new JSONObject to hold the updated department data
                JSONObject updatedDepartment = new JSONObject();
                try {
                    updatedDepartment.put("name", updatedName);
                    updatedDepartment.put("description", updatedDescription);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

                // Send a PUT request to update the department
                String updateUrl = "http://192.168.0.11:8080/departments"; // Replace with your server URL
                String departmentId = String.valueOf(id); // Convert the department ID to a string
                String requestBody = updatedDepartment.toString(); // Convert the JSON object to a string
                new UpdateDepartmentTask().execute(updateUrl, departmentId, requestBody);
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private class AddDepartmentTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String url = params[0];
            String requestBody = params[1];
            APIHandler handler = new APIHandler();
            return handler.sendPostRequest(url, requestBody);
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            new DepartmentActivity.ReadAPI().execute("http://192.168.0.11:8080/departments");
        }
    }

    private class UpdateDepartmentTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String url = params[0];
            String departmentId = params[1];
            String requestBody = params[2];
            APIHandler handler = new APIHandler();
            return handler.sendPutRequest(url + "/" + departmentId, requestBody);
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            new ReadAPI().execute("http://192.168.0.11:8080/departments");
        }
    }

    private class DeleteDepartmentTask extends AsyncTask<Integer, Void, String> {
        @Override
        protected String doInBackground(Integer... params) {
            int departmentId = params[0];
            String deleteUrl = "http://192.168.0.11:8080/departments";
            String deleteUrlWithId = deleteUrl + "/" + departmentId;
            APIHandler handler = new APIHandler();

            // Delete the department
            String deleteDepartmentResponse = handler.sendDeleteRequest(deleteUrlWithId);

            // Return the response from deleting the department
            return deleteDepartmentResponse;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            new ReadAPI().execute("http://192.168.0.11:8080/departments");
        }
    }
}
