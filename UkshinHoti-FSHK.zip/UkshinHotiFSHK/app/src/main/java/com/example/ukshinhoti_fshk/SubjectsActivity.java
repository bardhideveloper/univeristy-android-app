package com.example.ukshinhoti_fshk;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.List;

public class SubjectsActivity extends AppCompatActivity {

    private ListView listOfSubjects;
    private Button addButton;
    private List<String> subjectList;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subjects);

        // Enable the "Go Back" button in the app bar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        listOfSubjects = findViewById(R.id.listOfSubjects);

        subjectList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, subjectList);
        listOfSubjects.setAdapter(adapter);

        new ReadAPI().execute("http://192.168.0.11:8080/subjects");
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed(); // Go back to the previous activity
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private class ReadAPI extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {
            String url = strings[0];
            APIHandler handler = new APIHandler();
            return handler.readJson(url);
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            try {
                JSONArray jsonArray = new JSONArray(result);
                List<JSONObject> allSubjects = new ArrayList<>();
                subjectList.clear();

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    allSubjects.add(jsonObject);
                }

                ArrayAdapter<JSONObject> adapter = new ArrayAdapter<JSONObject>(SubjectsActivity.this,
                        R.layout.list_item_subject, allSubjects) {
                    @NonNull
                    @Override
                    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                        if (convertView == null) {
                            convertView = LayoutInflater.from(getContext()).inflate(R.layout.list_item_subject, parent, false);
                        }

                        JSONObject subject = getItem(position);

                        TextView nameTextView = convertView.findViewById(R.id.textViewSubjectName);
                        TextView creditsTextView = convertView.findViewById(R.id.textViewSubjectCredits);


                        try {
                            // Set the department name and description
                            String subjectName = subject.getString("name");
                            String subjectCredits = subject.getString("credits");
                            nameTextView.setText(subjectName);
                            creditsTextView.setText(subjectCredits);
                        }catch (JSONException e) {
                                e.printStackTrace();
                            }
                        return convertView;
                    }
                };

                listOfSubjects.setAdapter(adapter);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

}
