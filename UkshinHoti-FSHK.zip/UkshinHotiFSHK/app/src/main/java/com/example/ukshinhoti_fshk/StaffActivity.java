package com.example.ukshinhoti_fshk;

import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.ukshinhoti_fshk.department.Department;
import com.example.ukshinhoti_fshk.department.Staff;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class StaffActivity extends AppCompatActivity {
    private ListView listOfStaff;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff);

        // Enable the "Go Back" button in the app bar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        listOfStaff = findViewById(R.id.listOfStaff);

        Button addStaffButton = findViewById(R.id.addStaffButton);
        addStaffButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showAddStaffDialog();
            }
        });

        // Retrieve the department ID from the intent
        int departmentId = getIntent().getIntExtra("departmentId",+1);
        System.out.println("id: "+departmentId);

        // Construct the URL to fetch staff data for the given department ID
        String url = "http://192.168.0.11:8080/departments/" + departmentId + "/staff";

        // Execute the API request to fetch staff data
        new ReadStaffAPI().execute(url);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed(); // Go back to the previous activity
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    //Listener to add a new Staff
    private void showAddStaffDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Add Staff");

        // Inflate the dialog layout XML file
        View view = getLayoutInflater().inflate(R.layout.dialog_add_staff, null);
        builder.setView(view);

        // Get references to the EditText fields
        EditText OfficeNumberEditText = view.findViewById(R.id.editTextOfficeNumber);
        EditText FloorEditText = view.findViewById(R.id.editTextFloor);
        EditText ProfessorEmailEditText = view.findViewById(R.id.editTextProfessorEmail);
        EditText ConsultationHoursEditText = view.findViewById(R.id.editTextConsultationHours);

        // Retrieve the department ID from the intent
        int departmentId = getIntent().getIntExtra("departmentId", -1);

        builder.setPositiveButton("Add", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String OfficeNumber = OfficeNumberEditText.getText().toString().trim();
                String Floor = FloorEditText.getText().toString().trim();
                String ProfessorEmail = ProfessorEmailEditText.getText().toString().trim();
                String ConsultationHours = ConsultationHoursEditText.getText().toString().trim();

                // Create a new JSONObject to hold the staff data
                JSONObject staff = new JSONObject();
                try {
                    staff.put("officeNumber", OfficeNumber);
                    staff.put("floor", Floor);
                    staff.put("professorEmail", ProfessorEmail);
                    staff.put("consultationHours", ConsultationHours);
                    staff.put("departmentId",departmentId);

                } catch (JSONException e) {
                    e.printStackTrace();
                }

                // Send a POST request to add the new staff member
                String addUrl = "http://192.168.0.11:8080/staff/add"; // Replace with your server URL
                String requestBody = staff.toString(); // Convert the JSON object to a string
                new StaffActivity.AddStaffTask().execute(addUrl, requestBody);
            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        AlertDialog alertDialog = builder.create();
        alertDialog.show();
    }

    private class ReadStaffAPI extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {
            String url = strings[0];
            APIHandler handler = new APIHandler();
            return handler.readJson(url);
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            try {
                JSONArray jsonArray = new JSONArray(result);
                List<Staff> staffList = new ArrayList<>();

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                    long id = jsonObject.getLong("id");
                    String officeNumber = jsonObject.getString("officeNumber");
                    String floor = jsonObject.getString("floor");
                    String professorEmail = jsonObject.getString("professorEmail");
                    String consultationHours = jsonObject.getString("consultationHours");

                    // Create a new Staff object
                    Staff staff = new Staff(id, officeNumber, floor, professorEmail, consultationHours,null);
                    staffList.add(staff);
                }

                ArrayAdapter<Staff> adapter = new ArrayAdapter<Staff>(StaffActivity.this, R.layout.list_item_staff, R.id.textViewOfficeNumber, staffList) {
                    @NonNull
                    @Override
                    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                        if (convertView == null) {
                            convertView = getLayoutInflater().inflate(R.layout.list_item_staff, parent, false);
                        }

                        Staff staff = getItem(position);

                        TextView textViewOfficeNumber = convertView.findViewById(R.id.textViewOfficeNumber);
                        TextView textViewFloor = convertView.findViewById(R.id.textViewFloor);
                        TextView textViewProfessorEmail = convertView.findViewById(R.id.textViewProfessorEmail);
                        TextView textViewConsultationHours = convertView.findViewById(R.id.textViewConsultationHours);

                        textViewOfficeNumber.setText("Office: " + staff.getOfficeNumber());
                        textViewFloor.setText("Floor: " + staff.getFloor());
                        textViewProfessorEmail.setText("Email: " + staff.getProfessorEmail());
                        textViewConsultationHours.setText("Consultation Hours: " + staff.getConsultationHours());

                        convertView.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                showEditDeleteDialog(staff);
                            }
                        });

                        return convertView;
                    }
                };

                listOfStaff.setAdapter(adapter);

                listOfStaff.setAdapter(adapter);

            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class AddStaffTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String url = params[0];
            String requestBody = params[1];
            APIHandler handler = new APIHandler();

            try {
                JSONObject staffObject = new JSONObject(requestBody);

                return handler.sendPostRequest(url, staffObject.toString());
            } catch (JSONException e) {
                e.printStackTrace();
                return null;
            }
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            int departmentId = getIntent().getIntExtra("departmentId",+1);
            // Construct the URL to fetch staff data for the given department ID
            String url = "http://192.168.0.11:8080/departments/" + departmentId + "/staff";

            // Execute the API request to fetch staff data
            new ReadStaffAPI().execute(url);
        }
    }

    private void showEditStaffDialog(Staff staff) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Staff");

        // Inflate the dialog layout XML file
        View view = getLayoutInflater().inflate(R.layout.dialog_edit_staff, null);
        builder.setView(view);

        // Get references to the EditText fields
        EditText officeNumberEditText = view.findViewById(R.id.editTextOfficeNumber);
        EditText floorEditText = view.findViewById(R.id.editTextFloor);
        EditText professorEmailEditText = view.findViewById(R.id.editTextProfessorEmail);
        EditText consultationHoursEditText = view.findViewById(R.id.editTextConsultationHours);

        // Pre-fill the EditText fields with the existing values
        officeNumberEditText.setText(staff.getOfficeNumber());
        floorEditText.setText(staff.getFloor());
        professorEmailEditText.setText(staff.getProfessorEmail());
        consultationHoursEditText.setText(staff.getConsultationHours());

        builder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String officeNumber = officeNumberEditText.getText().toString().trim();
                String floor = floorEditText.getText().toString().trim();
                String professorEmail = professorEmailEditText.getText().toString().trim();
                String consultationHours = consultationHoursEditText.getText().toString().trim();

                // Update the staff member with the new values
                staff.setOfficeNumber(officeNumber);
                staff.setFloor(floor);
                staff.setProfessorEmail(professorEmail);
                staff.setConsultationHours(consultationHours);

                // Send a PUT request to update the staff member
                String updateUrl = "http://192.168.0.11:8080/staff/" + staff.getId(); // Replace with your server URL
                String requestBody = staffToJson(staff); // Convert the Staff object to a JSON string
                new UpdateStaffTask().execute(updateUrl, requestBody);
            }
        });

        builder.setNegativeButton("Cancel", null);

        builder.show();
    }

    private void showDeleteStaffDialog(Staff staff) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Delete Staff");
        builder.setMessage("Are you sure you want to delete this staff member?");

        builder.setPositiveButton("Delete", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // Send a DELETE request to remove the staff member
                String deleteUrl = "http://192.168.0.11:8080/staff/" + staff.getId(); // Replace with your server URL
                new DeleteStaffTask().execute(deleteUrl);
            }
        });

        builder.setNegativeButton("Cancel", null);

        builder.show();
    }


    private void showEditDeleteDialog(Staff staff) {
        AlertDialog.Builder builder = new AlertDialog.Builder(StaffActivity.this);
        builder.setTitle("Options");
        builder.setItems(new CharSequence[]{"Edit", "Delete"}, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (which == 0) {
                    // Edit option clicked
                    showEditStaffDialog(staff);
                } else if (which == 1) {
                    // Delete option clicked
                    showDeleteStaffDialog(staff);
                }
            }
        });
        builder.show();
    }
    private String staffToJson(Staff staff) {
        // Create a new JSONObject to hold the staff data
        JSONObject staffObject = new JSONObject();
        try {
            staffObject.put("id", staff.getId());
            staffObject.put("officeNumber", staff.getOfficeNumber());
            staffObject.put("floor", staff.getFloor());
            staffObject.put("professorEmail", staff.getProfessorEmail());
            staffObject.put("consultationHours", staff.getConsultationHours());
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return staffObject.toString();
    }

    private class UpdateStaffTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String url = params[0];
            String requestBody = params[1];
            APIHandler handler = new APIHandler();

            return handler.sendPutRequest(url, requestBody);
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            // Refresh the staff list after updating the staff member
            String url = "http://192.168.0.11:8080/staff"; // Replace with your server URL
            new ReadStaffAPI().execute(url);
        }
    }

    private class DeleteStaffTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... params) {
            String url = params[0];
            APIHandler handler = new APIHandler();

            return handler.sendDeleteRequest(url);
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);

            // Refresh the staff list after deleting the staff member
            String url = "http://192.168.0.11:8080/staff"; // Replace with your server URL
            new ReadStaffAPI().execute(url);
        }
    }

}