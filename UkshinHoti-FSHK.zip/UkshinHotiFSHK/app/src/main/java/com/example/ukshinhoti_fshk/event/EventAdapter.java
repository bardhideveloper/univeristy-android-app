package com.example.ukshinhoti_fshk.event;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.ukshinhoti_fshk.R;

import java.util.List;

public class EventAdapter extends ArrayAdapter<Event> {
    private Context context;
    private List<Event> events;
    public EventAdapter(Context context, List<Event> events) {
        super(context, 0, events);
        this.context = context;
        this.events = events;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView == null) {
            convertView = LayoutInflater.from(context).inflate(R.layout.event_item, parent, false);
        }

        // Get the event at the specified position
        Event event = events.get(position);

        // Bind event data to the views in the item layout
        TextView titleTextView = convertView.findViewById(R.id.event_title);
        TextView dateTextView = convertView.findViewById(R.id.event_date);
        TextView descriptionTextView = convertView.findViewById(R.id.event_description);

        titleTextView.setText(event.getTitle());
        dateTextView.setText(event.getDate());
        descriptionTextView.setText(event.getDescription());

        return convertView;
    }
}