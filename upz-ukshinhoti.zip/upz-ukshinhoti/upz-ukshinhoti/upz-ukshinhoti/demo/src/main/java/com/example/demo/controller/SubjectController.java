package com.example.demo.controller;

import com.example.demo.model.Department;
import com.example.demo.model.Staff;
import com.example.demo.model.Subject;
import com.example.demo.repository.DepartmentRepository;
import com.example.demo.repository.SubjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

@RestController
public class SubjectController {

    @Autowired
    private SubjectRepository subjectRepository;

    @Autowired
    private DepartmentRepository departmentRepository;

    @GetMapping("/subjects")
    public List<Subject> getSubject() {
        return subjectRepository.findAll();
        // return listOfMessages;
    }

    @PostMapping("/subjects/add")
    public Subject insertSubject(@RequestBody Subject subject) {
        Optional<Department> d=departmentRepository.findById(Long.valueOf(subject.getDepartmentId()));
        subject.setDepartment(d.get());
        return subjectRepository.save(subject);
    }

    @PutMapping("/subjects/{id}")
    public Subject editSubject(@PathVariable Long id, @RequestBody Subject subject) {

        Subject existingSubject = subjectRepository.findById(id).orElseThrow(() -> new NoSuchElementException("Subject with ID " + id + " not found"));
        existingSubject.setName(subject.getName());
        existingSubject.setCredits(subject.getCredits());
        existingSubject.setDepartment(subject.getDepartment());
        return subjectRepository.save(existingSubject);
    }

    @DeleteMapping("/subjects/{id}")
    public void deleteSubject(@PathVariable Long id) {
        subjectRepository.deleteById(id);
    }

}
