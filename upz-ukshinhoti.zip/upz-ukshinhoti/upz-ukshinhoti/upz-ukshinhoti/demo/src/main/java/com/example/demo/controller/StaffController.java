package com.example.demo.controller;


import com.example.demo.model.Department;
import com.example.demo.model.Staff;
import com.example.demo.repository.DepartmentRepository;
import com.example.demo.repository.StaffRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

@RestController
public class StaffController {

    @Autowired
    private StaffRepository staffRepository;
    @Autowired
    private DepartmentRepository departmentRepository;

    @GetMapping("/staff")
    public List<Staff> getStaff() {
        return staffRepository.findAll();
    }

    @PostMapping("/staff/add")
    public Staff insertStaff(@RequestBody Staff staff) {
        Optional<Department> d=departmentRepository.findById(Long.valueOf(staff.getDepartmentId()));
        staff.setDepartment(d.get());
        return staffRepository.save(staff);
    }

    @PutMapping("/staff/{id}")
    public Staff editStaff(@PathVariable Long id, @RequestBody Staff staff) {
        Staff existingStaff = staffRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Staff with ID " + id + " not found"));

        existingStaff.setOfficeNumber(staff.getOfficeNumber());
        existingStaff.setFloor(staff.getFloor());
        existingStaff.setProfessorEmail(staff.getProfessorEmail());
        existingStaff.setConsultationHours(staff.getConsultationHours());
        existingStaff.setDepartment(staff.getDepartment());
        existingStaff.setSubject(staff.getSubject());

        return staffRepository.save(existingStaff);
    }

    @DeleteMapping("/staff/{id}")
    public void deleteStaff(@PathVariable Long id) {
        staffRepository.deleteById(id);
    }
}