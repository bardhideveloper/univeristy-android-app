package com.example.demo.controller;

import com.example.demo.model.Department;
import com.example.demo.model.Staff;
import com.example.demo.model.Subject;
import com.example.demo.repository.DepartmentRepository;
import com.example.demo.repository.StaffRepository;
import com.example.demo.repository.SubjectRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

@RestController
public class DepartmentController {

    @Autowired
    private DepartmentRepository departmentRepository;

    @Autowired
    private StaffRepository staffRepository;

    @Autowired
    private SubjectRepository subjectRepository;

    @GetMapping("/departments")
    public List<Department> getAllDepartments() {
        return departmentRepository.findAll();
    }

    @GetMapping("/departments/{id}")
    public Department getDepartmentById(@PathVariable Long id) {
        return departmentRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Department not found with id: " + id));
    }

    @PostMapping("/departments")
    public Department createDepartment(@RequestBody Department department) {
        return departmentRepository.save(department);
    }

    @PutMapping("/departments/{id}")
    public Department updateDepartment(@PathVariable Long id, @RequestBody Department department) {
        Department existingDepartment = departmentRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Department not found with id: " + id));

        existingDepartment.setName(department.getName());
        existingDepartment.setDescription(department.getDescription());

        return departmentRepository.save(existingDepartment);
    }

    @DeleteMapping("/departments/{id}")
    public void deleteDepartment(@PathVariable Long id) {
        departmentRepository.deleteById(id);
    }

    @GetMapping("/departments/{id}/staff")
    public List<Staff> getStaffByDepartmentId(@PathVariable Long id) {
        Department department = departmentRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Department not found with id: " + id));

        return department.getStaffList();
    }

    @GetMapping("/departments/{id}/subjects")
    public List<Subject> getSubjectByDepartmentId(@PathVariable Long id) {
        Department department = departmentRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Department not found with id: " + id));

        return department.getSubjectList();
    }

    @PostMapping("/departments/{id}/subjects")
    public Subject createSubjectsInDepartment(@PathVariable Long id, @RequestBody Subject subject) {
        Department department = departmentRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Department not found with id: " + id));

        subject.setDepartment(department);
        return subjectRepository.save(subject);
    }

    // Additional methods for updating, deleting, and retrieving individual staff members

    // ...
}